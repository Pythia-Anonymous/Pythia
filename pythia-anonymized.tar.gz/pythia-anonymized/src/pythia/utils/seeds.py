""" Implements core logic to iterate over the seeds available in the corpus. """
from __future__ import print_function
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import random
SEED=12345
random.seed(SEED)
import subprocess
import numpy as np
import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)


def select_random_seed(hps, args, sess, inputs_raw_tf, inputs_ast_tf,
                       outputs_tf):
    """ Iterates over the corpus of available seeds.

    Despite the many arguments, this function is rather simple and it just tries
    to find the total number of different test cases in the seed corpus, and the
    iterates over them using tensors defined in the corresponing dataset module.
    """
    if not select_random_seed.seeds:
        # Try getting the size of the dataset
        try:
            out = subprocess.Popen(['wc', '-l', hps.dataset],
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
            stdout, stderr = out.communicate()
            n_lines = int(stdout.split(" ")[0]) - 1
            n_iter = int(n_lines / hps.batch_size) + 1
        except Exception, error:
            n_iter = 100

        print("Start loading seeds from {} (n_iter: {}).".\
              format(hps.dataset, n_iter), file=args.f)
        length_counter = 0
        for _ in range(0, n_iter):
            inputs_raw, inputs_ast, outputs = sess.run([inputs_raw_tf,
                                                        inputs_ast_tf,
                                                        outputs_tf])
            for ii in range(hps.batch_size):
                bitmap_hash = len(select_random_seed.seeds) + 1
                select_random_seed.seeds[bitmap_hash] = (
                    inputs_raw[ii],
                    inputs_ast[ii],
                    outputs[ii]
                )
                length_counter += len(inputs_ast[ii])

        print("Loaded {} seeds".\
              format(len(select_random_seed.seeds)),
              file=args.f)
        print("Average sequence length:",
              length_counter/len(select_random_seed.seeds), file=args.f)
    if select_random_seed.last_seed_i == len(select_random_seed.seeds):
        select_random_seed.last_seed_i = 0

    bitmap_hash =  select_random_seed.seeds.keys()[select_random_seed.last_seed_i]
    inputs_raw = select_random_seed.seeds[bitmap_hash][0]
    inputs_ast = select_random_seed.seeds[bitmap_hash][1]
    outputs = select_random_seed.seeds[bitmap_hash][2]
    select_random_seed.last_seed_i += 1
    return inputs_raw, inputs_ast, outputs
select_random_seed.seeds = {}
select_random_seed.last_seed_i = 0
