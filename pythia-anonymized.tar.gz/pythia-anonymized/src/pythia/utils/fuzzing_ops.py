""" Implementation of Pythia and various helpers.


The main functions are
----------------------
    * do_fuzzing_stacked: Algorithm-1 from the paper.

    * do_execute_sequence: Implements stateful REST API fuzzing and mutations.

    * do_garbage_collection: Implements a simple garbage collector.

"""
from __future__ import print_function
import itertools
import os
import sys
import json
import time
import uuid
import random
SEED=12345
random.seed(SEED)
import hashlib
import traceback
import subprocess
import numpy as np
import tensorflow as tf

import network_ops
import datasets
from pythia.models import params
import seeds


class TimeOutException(Exception):
    """ Time budget expired. """
    pass


class OutOfSeedsException(Exception):
    """ No seeds available. """
    pass


class OutdatedModelException(Exception):
    """ New model available after retraining. """
    pass


def my_print(sequence, args):
    """ Debug helper. """
    for s, _, _ in sequence:
        print(repr(s.replace("\\r", "\r").replace("\\n", "\n")), file=args.f)
    print(file=args.f)


def set_latest_model_ts(args):
    """ Updates the path of the most recent model. """
    try:
        latest_model_paths = [os.path.join(args.model_dir_ae, d)
                             for d in os.listdir(args.model_dir_ae)
                             if os.path.isdir(os.path.join(args.model_dir_ae, d))]

        latest_model_paths = map(lambda x: int(x.split("_")[-1]),
                                 latest_model_paths)
        args.latest_model_ts = max(latest_model_paths)
    except Exception, error:
        args.latest_model_ts = None


def set_latest_dataset_hps(hps):
    """ Updates the path of the most recent dataset. """
    try:
        dataset_dirname = os.path.dirname(hps.dataset)
        datasets_name = [f for f in os.listdir(dataset_dirname)
                         if os.path.isfile(os.path.join(dataset_dirname, f))
                         and 'augmented' in f]
        datasets_name = map(lambda x: x.replace(".txt", ""), datasets_name)
        assert len(datasets_name)

        datasets_name_prefix = map(lambda x: "_".join(x.split("_")[:-1]),
                                   datasets_name)
        datasets_name_suffix = map(lambda x: int(x.split("_")[-1]), datasets_name)
        max_suffix = max(datasets_name_suffix)
        latest_dataset_path = os.path.join(
            dataset_dirname,
            "{}_{}.txt".format(datasets_name_prefix[0], max_suffix)
        )
        updated_hps = params.update(hps, 'dataset', latest_dataset_path)
        return updated_hps
    except Exception, error:
        return hps


def is_current_model_outdated(args):
    """ Checks if there exists a new model to load. """
    try:
        latest_model_paths = [os.path.join(args.model_dir_ae, d)
                             for d in os.listdir(args.model_dir_ae)
                             if os.path.isdir(os.path.join(args.model_dir_ae, d))]
        latest_model_paths = map(lambda x: int(x.split("_")[-1]),
                                 latest_model_paths)
        return max(latest_model_paths) > args.latest_model_ts
    except Exception, error:
        return False


def is_latest_model_complete(args):
    """ Checks if training is over. """
    try:
        latest_model_paths = [os.path.join(args.model_dir_ae, d)
                             for d in os.listdir(args.model_dir_ae)
                             if os.path.isdir(os.path.join(args.model_dir_ae, d))]
        latest_model_paths = map(lambda x: int(x.split("_")[-1]),
                                 latest_model_paths)
        latest_model_path = os.path.join(
            args.model_dir_ae,
            ".model_{}".format(max(latest_model_paths))
        )
        return "copying_complete" in os.listdir(latest_model_path)
    except Exception, error:
        print(error)
        return False


def monitor_coverage(args):
    try:
        out = subprocess.Popen(
            ['tail', '-n', '1', '/tmp/coverage_stats.txt'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT
        )
        stdout, stderr = out.communicate()
        latest_coverage = int(stdout.split("\n")[0].split(":")[3])
    except Exception:
        latest_coverage = -1

    print("{}: Current coverage: {}".format(int(time.time()*10**6),
                                            latest_coverage),
          file=args.f)
    return latest_coverage


def do_garbage_collection(cache, args):
    """ Implements Pythia's garbace collector.

    After a user-defined garbage collection life time, this function is invoked
    inn order to obtain the ids of all objects successfully created
    in the target service. Depending on the type of each object, if
    corresponding destructors are available (i.e., DELETE requests), the
    garbage collectore asynchronously invokes them, in order to remove redundant
    objects from the target service.

    @param cache: A dictionary of all object types and the corresponding ids of
    succesfully created objects over time
    @type  cache: Dict
    @param args: Command line arguments
    @type  args: ArgParser

    @return: None
    @rtype:  None
    """
    # GC off
    if args.gc_interval < 0:
        return

    # GC timeout not expired
    if not do_garbage_collection.ts_latest_gc:
        do_garbage_collection.ts_latest_gc = int(time.time())
        return
    if int(time.time()) - do_garbage_collection.ts_latest_gc < args.gc_interval:
        return

    # Set up some arguments
    class GarbageCollectorArgs(object):
        pass
    try:
        model_dir = args.model_dir
    except AttributeError:
        model_dir = args.model_dir_ae
    gc_args = GarbageCollectorArgs()
    gc_args.f = open(os.path.join(model_dir, "garbage_collector.txt"), "a")
    gc_args.target_ip = args.target_ip
    gc_args.target_port = args.target_port

    # Do the clean up
    print("{}: GC invoked (period: {} seconds):: current lenght of cache: {}".\
          format(int(time.time()*10**6), args.gc_interval, len(cache)),
          file=gc_args.f)

    for producer_request, resource_id in cache[::-1]:
        try:
            producer_request = producer_request.replace("\\r", "\r").\
                replace("\\n", "\n")
            producer_prefix = str(producer_request).split("\r\n\r\n")[0]
            producer_prefix = producer_prefix.split(" ")
            destructor_request = "DELETE {}/{} {}\r\n\r\n".\
                format(producer_prefix[1],
                       resource_id,
                       " ".join(producer_prefix[2:]))
            network_ops.sent_recv(destructor_request, gc_args)
        except Exception, error:
            print("{}: Exception:: {}".format(int(time.time()*10**6), error),
                  file=gc_args.f)
            traceback.print_exc(file=gc_args.f)

    # Reset cache and timeout
    del cache[:]
    do_garbage_collection.ts_latest_gc = int(time.time())
do_garbage_collection.ts_latest_gc = None


def execute_sequence(payload, args, ast_traversal, index=None, mutation=None,
                    aux=None, log_only=False):
    """ Executes mutated sequence on target service and invokes GC if no
    exeception occured (i.e., some objects were potentially crated.)

    Also see: do_execute_sequences
    """
    try:
        do_execute_sequence(payload, args, ast_traversal, index=index,
                           mutation=mutation, aux=aux, log_only=log_only)
        print("Coverage increase: {}".format(monitor_coverage(args)),
              file=args.f)
    except Exception:
        raise
    else:
        do_garbage_collection(do_execute_sequence.gc_cache, args)


def do_execute_sequence(payload, args, sequence_ast, index=None, mutation=None,
                       aux=None, log_only=False):
    """ Executes mutated sequence on target service. The functionality here is
    slightly complex because along with the mutated sequence (which may cause
    erroneous responses), also the respective responses must be parsed in order
    to obtain ids of the object created by the target service

    @param  payload: The payload of the secuence to execute
    @type   payload: Str
    @param  args: Command line arguments
    @type   args: ArgParser
    @param  sequence_ast: The production rules (AST nodes) of the secuence to
    execute
    @type   sequence_ast: List
    @param  index: Index of raw byte mutation
    @type   index: Int
    @param  mutation: Payload of raw byte mutation
    @type   mutation: Chr
    @param  aux: Raw byte-level mutations may introduce alternation on the leaf
    nodes that lead to new production rules which need to be added back and
    augment the initial set of production rules
    @type   aux: List
    @param  only_log: Debug flag controlling if we are only logging a sequence
    @type   only_log: Bool

    @return: None
    @rtype:  None
    """
    # Avoid logging for raw mutations since it's exactly the seed with a tiny
    # difference
    if mutation is None:
        my_print(payload, args)

    if log_only:
        return

    producers = {x[0]: x[0].__name__.replace("parse_", "")
                for _, _, x in payload if x}
    cache = {x[0].__name__.replace("parse_", ""): str(0)
             for _, _, x in payload if x}

    print("{}: Traversal: {}".\
          format(int(time.time()*10**6),
                 ",".join(map(str, sequence_ast.tolist()))),
          file=args.f)

    # Whenever there are structural mutations, the "aux" argument will be
    # set. However, there might be no payload mutation (i.e., not aux[0]),
    # or the payload mutation may be attempted at an internal/non-leaf node
    # of the AST (i.e., not aux[1]). At both of those case, the current
    # travensal cannot be used for augmentation of the grammar.
    if aux is not None and aux[0] and aux[1]:
        mutation_index = aux[0]
        mutation_rule_ascii = aux[1]
        print("{}: Aux-Traversal: {}:{}".\
              format(int(time.time()*10**6),
                     mutation_index,
                     ",".join(map(str, mutation_rule_ascii))),
              file=args.f)

    elif aux is None:
        print("{}: Aux-Traversal: {}".\
              format(int(time.time()*10**6),
                     "NOT_AVAILABLE: no structural mutation"),
              file=args.f)

    elif not aux[0]:
        print("{}: Aux-Traversal: {}".\
              format(int(time.time()*10**6),
                     "NOT_AVAILABLE: no payload mutation"),
              file=args.f)

    elif not aux[1]:
        print("{}: Aux-Traversal: {}".\
              format(int(time.time()*10**6),
                     "NOT_AVAILABLE: not a leaf"),
              file=args.f)

    bytes_processed = 0
    raw_mutation_done = False
    for request_i, (request, consumers, producer) in enumerate(payload):
        for consumer in consumers:
            _consumer = str(consumer).replace("_", "")
            try:
                # This is neccessary to handle non-unicord fuzzable payloads.
                request_ascii = ",".join(map(str, map(ord, list(request))))
                consumer_type_ascii = ",".join(
                    map(str, map(ord, list(consumer))))
                consumer_value_ascii = ",".join(
                    map(str, map(ord, list(cache[_consumer]))))
                delim_start_ascii = ",".join(
                    map(str, map(ord, list("READER_START_"))))
                delim_end_ascii = ",".join(
                    map(str, map(ord, list("_READER_END"))))
                request_ascii = request_ascii.replace(
                    delim_start_ascii + "," + consumer_type_ascii + ","\
                    + delim_end_ascii,
                    consumer_value_ascii
                )
                request_ascii = map(int, request_ascii.split(","))
                request =  "".join(map(chr, request_ascii))
            except Exception, error:
                print("Parsing exception (consumer):", error, file=args.f)
                return

        # Handle uuids in place.
        request = request.replace("restler_fuzzable_uuid", uuid.uuid4().hex[:22])
        bytes_processed += len(request)

        # Apply raw mutations
        if mutation is not None and bytes_processed >= index\
                and not raw_mutation_done:
            request_ascii = ",".join(map(str, map(ord, list(request))))
            request_ascii = map(int, request_ascii.split(","))
            position = min(bytes_processed - index, len(request_ascii) - 1)
            request_ascii[position] = mutation
            request =  "".join(map(chr, request_ascii))
            raw_mutation_done = True

        # Send request over network and  get response
        try:
            t1 = int(time.time()*10**6)
            response = network_ops.sent_recv(request, args, emit_hex=True)
            args.network_ops_time += int(time.time()*10**6) - t1
            try:
                status_code = int(response[9:12])
                if status_code not in args.status_codes:
                    args.status_codes[status_code] = 0
                args.status_codes[status_code] += 1
            except Exception, error:
                pass

        except Exception, error:
            args.exceptions += len(sequence_ast) - request_i
            print("Network level exception: {} --  skipping.".format(error),
                  file=args.f)
            return

        # If it's a producer, use the corresponding parser
        if producer:
            try:
                cache[producers[producer[0]]] = producer[0](response)
                do_execute_sequence.gc_cache.append((
                    request, cache[producers[producer[0]]]))
            except Exception, error:
                args.exceptions += len(sequence_ast) - request_i
                print("Parsing exception (producer):", error, file=args.f)
                return

        args.successes += 1

    print(file=args.f)
    args.f.flush()
do_execute_sequence.gc_cache = []


def do_fuzzing_ffwd_raw(hps, args, seed_sequence_raw, seed_sequence_ast):
    """ Mutates a seed test case using the baseline raw fuzzer.

    @param hps: Model hyperparameters (not needed here)
    @type  hps: HParam
    @param args: Command line arguments
    @type  args: ArgParser
    @param seed_sequence_raw: The seed sequence to be mutated in raw bytes
    @type  seed_sequence_raw: List
    @param seed_sequence_ast: The seed sequence to be mutated as a list of AST
    production rules
    @type  seed_sequence_ast: List

    @return: None
    @rtype:  None

    Note: the seed sequence AST representation is also passed as an argument
    here because some of the helpers are defined to operate only on the
    production rules granularity.
    """
    # Revert the numeric sequence augmented with the special ids for the
    # language models (such as "<EOS>", "<UNK>", and "<PAD>") back to a sequence
    # that solely contains RESTler's production rules and is reconstructible,
    # and afterwards replayable over the network.
    seed_sequence_ast_rules_numeric = list(seed_sequence_ast)
    seed_sequence_ast_rules_numeric_reverted = np.array(
        datasets.revert(seed_sequence_ast_rules_numeric))

    # Revert production rules back to actual payloads tranferable over sockers.
    seed_sequence_payload, aux = datasets.reconstruct_sequence_from_ast(
        seed_sequence_ast_rules_numeric_reverted, hps)

    min_byte_id = 0
    max_byte_id = 255
    print("Seed sequence:", file=args.f)
    execute_sequence(seed_sequence_payload, args,
                    seed_sequence_ast_rules_numeric_reverted, log_only=True)

    valid_new_seed_sequences = 0
    valid_new_seed_sequences_aux = []
    valid_new_seed_sequences_payloads = []
    cur_len = len(seed_sequence_raw)

    # Randomly select and mutate a leaf node (retry 1000 times)
    for retries in range(10**3):
        print("Retry: {}".format(retries), file=args.f)
        mutated_seed_sequence_raw = list(seed_sequence_raw)
        mutation = np.random.randint(min_byte_id, max_byte_id + 1)
        mutation_index = np.random.randint(0, cur_len)
        mutated_seed_sequence_raw[mutation_index] = mutation

        old_rule = seed_sequence_raw[mutation_index]
        new_rule = mutation
        if old_rule == new_rule:
            continue

        print("Old rule @{}:{}".format(mutation_index, repr(chr(old_rule))),
              file=args.f)
        print("New rule @{}:{}".format(mutation_index, repr(chr(new_rule))),
              file=args.f)
        print("Total different mutations:", len(do_fuzzing_ffwd_raw.mutations),
              file=args.f)
        do_fuzzing_ffwd_raw.mutations.add((mutation_index, old_rule, new_rule))
        print("Executing mutated sequence", file=args.f)
        execute_sequence(seed_sequence_payload, args,
                        seed_sequence_ast_rules_numeric_reverted,
                        index=mutation_index,
                        mutation=mutation)
        if int(time.time()*10**6) - args.start_time > args.time_budget:
            raise TimeOutException()
        # Stop once one successful mutation is performed
        break

    # Abort when time budget expires
    if int(time.time()*10**6) - args.start_time > args.time_budget:
        raise TimeOutException()
# Dictionary of debug metadata
do_fuzzing_ffwd_raw.mutations = set()


def do_fuzzing_ffwd_ast(hps, args, seed_sequence):
    """ Mutates a seed test case using the baseline AST fuzzer.

    @param hps: Model hyperparameters (not needed here)
    @type  hps: HParam
    @param args: Command line arguments
    @type  args: ArgParser
    @param seed_sequence: The seed sequence to be mutated as a list of AST
    production rules
    @type  seed_sequence: List

    @return: None
    @rtype:  None
    """
    # Revert the numeric sequence augmented with the special ids for the
    # language models (such as "<EOS>", "<UNK>", and "<PAD>") back to a sequence
    # that solely contains RESTler's production rules and is reconstructible,
    # and afterwards replayable over the network.
    seed_sequence_ast_rules_numeric = list(seed_sequence)
    seed_sequence_ast_rules_numeric_reverted = np.array(
        datasets.revert(seed_sequence_ast_rules_numeric))

    # Revert production rules back to actual payloads tranferable over sockers
    seed_sequence_payload, aux = datasets.reconstruct_sequence_from_ast(
        seed_sequence_ast_rules_numeric_reverted,
        hps
    )

    # Retrieve production rules
    production_rules = datasets.reconstruct_sequence_from_ast.id2rule
    min_rule_id = min(production_rules.keys())
    max_rule_id = max(production_rules.keys())

    print("Seed sequence:", file=args.f)
    execute_sequence(seed_sequence_payload, args,
                    seed_sequence_ast_rules_numeric_reverted, log_only=True)

    # Randomly select and mutate a leaf node (retry 1000 times)
    cur_len = len(seed_sequence_ast_rules_numeric_reverted)
    for retries in range(10**3):
        mutated_seed_sequence_ast_rules_numeric_reverted = list(
                seed_sequence_ast_rules_numeric_reverted)
        mutation = np.random.randint(min_rule_id, max_rule_id + 1)
        mutation_index = np.random.randint(0, cur_len)
        mutated_seed_sequence_ast_rules_numeric_reverted[mutation_index] = mutation

        old_rule_id = seed_sequence_ast_rules_numeric_reverted[mutation_index]
        old_rule = production_rules[old_rule_id]
        new_rule_id = mutation
        new_rule = production_rules[new_rule_id]
        if 'LEAF' not in new_rule or 'LEAF' not in old_rule:
            continue
        try:
            new_seed_sequence_payload, aux =\
                datasets.reconstruct_sequence_from_ast(
                    mutated_seed_sequence_ast_rules_numeric_reverted,
                    hps,
                    mutation_at_index=mutation_index
                )
        except KeyError, error:
            continue
        except datasets.SequenceReconstructionException, error:
            continue

        print("Retry: {}".format(retries), file=args.f)
        print("Old rule @{}:{} -- ".format(mutation_index, old_rule),
              "New rule @{}:{}".format(mutation_index, new_rule),
              file=args.f)
        print("Total different mutations:", len(do_fuzzing_ffwd_ast.mutations),
              file=args.f)
        do_fuzzing_ffwd_ast.mutations.add((mutation_index, old_rule, new_rule))
        print("Executing mutated sequence", file=args.f)
        execute_sequence(new_seed_sequence_payload, args,
                        seed_sequence_ast_rules_numeric_reverted,
                        aux=aux)
        if int(time.time()*10**6) - args.start_time > args.time_budget:
            raise TimeOutException()
        # Stop once one successful mutation is performed
        break

    # Abort when time budget expires
    if int(time.time()*10**6) - args.start_time > args.time_budget:
            raise TimeOutException()
# Dictionary of debug metadata
do_fuzzing_ffwd_ast.mutations = set()


def do_fuzzing_stacked(hps, args, sess, model_ae, seed_sequence, bitmap,
                       mutations_per_seed=1):
    # Revert the numeric sequence augmented with the special ids for the
    # language models (such as "<EOS>", "<UNK>", and "<PAD>") back to a sequence
    # that solely contains RESTler's production rules and is reconstructible,
    # and afterwards replayable over the network.
    seed_sequence_ast_rules_numeric = list(seed_sequence)
    seed_sequence_ast_rules_numeric_reverted = np.array(
        datasets.revert(seed_sequence_ast_rules_numeric))

    # Revert production rules back to actual payloads tranferable over sockers.
    seed_sequence_payload, aux = datasets.reconstruct_sequence_from_ast(
        seed_sequence_ast_rules_numeric_reverted,
        hps
    )

    # Retrieve production rules.
    production_rules = datasets.reconstruct_sequence_from_ast.id2rule
    min_rule_id = min(production_rules.keys())
    max_rule_id = max(production_rules.keys())

    print("Seed sequence:", file=args.f)
    execute_sequence(seed_sequence_payload, args,
                    seed_sequence_ast_rules_numeric_reverted, log_only=True)

    b_hash = hashlib.sha1(",".join(map(str, list(seed_sequence_ast_rules_numeric_reverted)))).hexdigest()
    print("Hash:", b_hash, "| Total:",
          len(do_fuzzing_stacked.seeds_cache.keys()), file=args.f)

    # Because forward passed on the seq2seq model are expensive (especially when
    # not using GPUs), Pythia does one forward pass, generates many mutations,
    # creates a queue of available mutations for each seed, and then operates
    # from the queue of available mutations and avoid new forward passed each
    # time a seed is revisited.
    if b_hash not in do_fuzzing_stacked.seeds_cache:
        do_fuzzing_stacked.seeds_cache[b_hash] = [[], 0]

        # Bound the step size by the norm of each seed in ouput of the encoder.
        feed_dict = {
               model_ae.inputs: np.repeat([seed_sequence_ast_rules_numeric],
                                           hps.batch_size, axis=0),
        }
        t1 = int(time.time()*10**6)
        encoder_state = sess.run(model_ae.encoder_state, feed_dict=feed_dict)
        args.gradient_ops_time += int(time.time()*10**6) - t1
        initial_bound = np.linalg.norm(np.mean(encoder_state[0], axis=0)) /\
            hps.rnn_size

        original_inputs = encoder_state[0]
        valid_new_seed_sequences_aux = []
        valid_new_seed_sequences_payloads = []

        # Get a new pertrubation of exponentially increasing size
        perturbed_inputs = np.array(original_inputs)
        perturbation = 2*(np.random.rand(hps.batch_size, hps.rnn_size) - 0.5)

        # Normaliza perturbations
        norm = np.linalg.norm(perturbation, axis=1, keepdims=True)
        normalized_perturbation = perturbation / norm

        # Exponential search on bounds sizes that cause a difference between
        # the input (seed) sequence and the output of the decoder.
        retry = 0
        bounds = np.zeros(hps.batch_size)
        for i in range(1, int(hps.batch_size / 2)):
            bounds[i] = initial_bound / (2 + retry*0.5)**i
        for i in range(int(hps.batch_size / 2), hps.batch_size):
            bounds[i] = initial_bound * (2 + retry*0.5)**i
        bounds = np.sort(bounds).reshape(-1, 1)

        # Scale perturbations
        scaled_perturbations = bounds*normalized_perturbation

        # Create perturbed decoder starting states
        perturbed_inputs += scaled_perturbations

        feed_dict_ae = {model_ae.mutated_encoder_state: perturbed_inputs}
        t1 = int(time.time()*10**6)
        rval = sess.run(model_ae.outputs_inference, feed_dict=feed_dict_ae)
        args.gradient_ops_time += int(time.time()*10**6) - t1

        # Since the model produces batches of outputs, take advantage of this
        # parallelization and check for perturbations all batched outputs
        adversarial_predictions = []
        predictions = map(datasets.revert, np.argmax(rval, axis=2))
        for i, prediction in enumerate(predictions[1:]):
            # Adversarial mutation not successful.
            if prediction == seed_sequence_ast_rules_numeric:
                continue
            # Training error.
            if prediction == predictions[0]:
                continue
            try:
                _, _ = datasets.reconstruct_sequence_from_ast(prediction, hps)
            except Exception:
                continue

            if prediction not in map(lambda x: x[0], adversarial_predictions):
                a = prediction
                b = seed_sequence_ast_rules_numeric_reverted
                min_len = min(len(a), len(b))
                max_len = max(len(a), len(b))
                edit_distance = np.sum(a[:min_len] != b[:min_len])
                edit_distance += max_len - min_len
                adversarial_predictions.append((prediction, edit_distance,
                                                bounds[i]))

        # Sort in order to prioritize the smallest bound for seed mutations
        adversarial_predictions.sort(key=lambda t: t[2])
        if adversarial_predictions:
            comm_indices = []
            a = seed_sequence_ast_rules_numeric_reverted
            # Pick prediction from smallest perturbation
            b = adversarial_predictions[0][0]

            # First obtain leaf locations that remain unchanged
            for ind in list(np.where(a[:min_len] == b[:min_len])[0]):
                if 'LEAF' not in production_rules[a[ind]]\
                        or 'LEAF' not in production_rules[b[ind]]:
                    continue
                comm_indices.append(ind)

            # Then obtain leaf locations that changed
            diff_indices = []
            a = seed_sequence_ast_rules_numeric_reverted
            b = adversarial_predictions[0][0]
            for ind in range(len(b), len(a)):
                if 'LEAF' not in production_rules[a[ind]]:
                    continue
                diff_indices.append(ind)

            # Find all grammar's leafs.
            production_rule_leafs = set()
            for rule_id in production_rules:
                if 'LEAF' in production_rules[rule_id]:
                    production_rule_leafs.add(rule_id)

            # Find all seed's leafs.
            seed_rule_leafs = set()
            for ind in range(len(a)):
                if 'LEAF' in production_rules[a[ind]]:
                    seed_rule_leafs.add(a[ind])

            # Apply perturbations and cap to 10,000 per seed (this cap is
            # very large already and if we start hitting it, it means
            # that the model is not well trained).
            list1 = []
            for mutation_index in comm_indices:
                target_rules = list(production_rule_leafs - seed_rule_leafs)
                for new_rule_id in target_rules:
                    list1.append((mutation_index, new_rule_id, False))
                if len(list1) > 10**4/2:
                    break

            list2 = []
            for mutation_index in diff_indices:
                target_rules = list(seed_rule_leafs)
                for new_rule_id in target_rules:
                    list2.append((mutation_index, new_rule_id, True))
                if len(list2) > 10**4:
                    break

            mutations_and_indices = [
                x for x in itertools.chain.from_iterable(
                    itertools.izip_longest(list1,list2)
                ) if x
            ]
            if (not list1 or not list2) and args.distillation != "on" :
                mutations_and_indices = []

            # Shuffle mutations randomize accross seeds and put them in the
            # queue of the current seed
            np.random.shuffle(mutations_and_indices)
            do_fuzzing_stacked.seeds_cache[b_hash][0] = mutations_and_indices

    # if no mutations were derived for this seed, then skip it. Situations in
    # which no mutations are derived may mean that either the perturbations
    # magnitude should be increased, or the model is not trained and it
    # propagates zero states.
    mutations_and_indices = do_fuzzing_stacked.seeds_cache[b_hash][0]
    if not mutations_and_indices:
        return

    # Keep track of mutations on the current seed and each time a seed is
    # reviseted, apply an new mutation.
    nth_mutation = do_fuzzing_stacked.seeds_cache[b_hash][1]
    do_fuzzing_stacked.seeds_cache[b_hash][1] += mutations_per_seed
    if nth_mutation == len(mutations_and_indices) - 1:
        do_fuzzing_stacked.seeds_cache[b_hash][0] = []
        do_fuzzing_stacked.seeds_cache[b_hash][1] = 0
    (mutation_index, mutation, pld_fuzz) = mutations_and_indices[nth_mutation]
    mutated = list(seed_sequence_ast_rules_numeric_reverted)
    mutated[mutation_index] = mutation
    old_rule = production_rules[
        seed_sequence_ast_rules_numeric_reverted[mutation_index]]
    new_rule = production_rules[mutation]

    # This metadata are primarily used for debuging purposes.
    print("{}: Old rule @{}:{} -- ".format(
          "pld_fuzz" if pld_fuzz else "no_pld_fuzz",
          mutation_index, old_rule),
          "New rule @{}:{}".format(mutation_index, new_rule),
          file=args.f)
    print("Total different mutations:", len(do_fuzzing_stacked.mutations),
          file=args.f)

    # Apply additional raw payload mutations (if applicable).
    do_fuzzing_stacked.mutations.add((mutation_index, old_rule, new_rule))
    if pld_fuzz:
        try:
            new_seed_sequence_payload, aux =\
                datasets.reconstruct_sequence_from_ast(
                    mutated,
                    hps,
                    mutation_at_index=mutation_index
                )
        except KeyError, error:
            return
        except datasets.SequenceReconstructionException, error:
            return
    else:
        try:
            new_seed_sequence_payload, aux =\
                datasets.reconstruct_sequence_from_ast(
                    mutated,
                    hps
                )
        except KeyError, error:
            return
        except datasets.SequenceReconstructionException, error:
            return

    # Execute mutated sequence
    print("Executing mutated sequence-{}/{}".\
          format(nth_mutation + 1, len(mutations_and_indices)), file=args.f)
    execute_sequence(new_seed_sequence_payload, args,
                    seed_sequence_ast_rules_numeric_reverted,
                    aux=aux)
    # Abort when time out expires
    if int(time.time()*10**6) - args.start_time >\
               args.time_budget:
            raise TimeOutException()
# Dictionary of debug metadata
do_fuzzing_stacked.mutations = set()
