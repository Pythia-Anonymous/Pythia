""" Implements network transfering functionality. """
from __future__ import print_function
import socket
import time
import ssl


TIMEOUT_CODE = '504'
DELIM = "\r\n\r\n"


def sent_recv(request, fuzzing_args, emit_hex=False):
    """ Sends a request over the network and receives back a reposponse.

    @param request: The request to be transfered (raw bytes)i
    @type  request: Str
    @param fuzzing_args: Command line arguments, including the target service
    ip and listening port
    @type  fuzzing_args: ArgParser
    @param emit_hex: Debug flag
    @type  emit_hex: Bool

    @return: The response received from the target service
    @rtype:  Str
    """
    if int(fuzzing_args.target_port) == 443:
        s = ssl.wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    else:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((fuzzing_args.target_ip, fuzzing_args.target_port))
    request = request.replace("\\r", "\r").replace("\\n", "\n")
    request = add_content_length(request)
    bytes_sent = s.send(request)
    print("{}: Sent: {}".format(int(time.time()*10**6), repr(request)),
            file=fuzzing_args.f)

    if emit_hex:
        data_hex = bytearray()
        data_hex.extend(request)
        data_hex = "".join(map(hex, data_hex))
        print("\n{}:Sending:{}\n".format(int(time.time()*10**6), data_hex),
              file=fuzzing_args.f)

    chunk = _recv(s)
    print("{}: Recv: {}".format(int(time.time()*10**6), repr(chunk)),
              file=fuzzing_args.f)
    s.close()
    return chunk


class TransportLayerException(Exception):
    """ Handles transport layer exceptions. """
    def __init__(self, value):
        self.parameter = value

    def __str__(self):
        return repr(self.parameter)


def _recv(sock, req_timeout_sec=600):
    """ Receives back a response from the target service.

    There are some interesting cases implemented here, in case of chucked transfer
    encoding etc. which are common to many services.
    """
    data = ''

    # get the data of header (and maybe more)
    while DELIM not in data:
        try:
            sock.settimeout(req_timeout_sec)
            buf = sock.recv(2**20)
        except socket.timeout:
            raise TransportLayerException(TIMEOUT_CODE)
        except Exception as error:
            raise TransportLayerException("Exception: {}".format(error))

        if len(buf) == 0:
            return data

        data += buf

    # Handle chunk encoding
    chuncked_encoding = False
    if 'Transfer-Encoding: chunked\r\n' in data or\
        'transfer-encoding: chunked\r\n' in data:
        chuncked_encoding = True
    if chuncked_encoding:
        while True:
            try:
                buf = sock.recv(2**20)
            except Exception as error:
                raise TransportLayerException("Exception: {}".format(error))

            if len(buf) == 0:
                return data

            data += buf
            if data.endswith("\r\n\r\n"):
                return data

    header_len = data.index(DELIM) + len(DELIM)


    if data[:12] in ["HTTP/1.1 204", "HTTP/1.1 304"]:
        content_len = 0
    else:
        try:
            data_lower = data.lower()
            content_len = data_lower.split("content-length: ")[1]
            content_len = int(content_len.split('\r\n')[0])
        except Exception as error:
            content_len = 2**20

    bytes_remain = content_len - len(data) + header_len

    # Get rest of socket data
    while bytes_remain > 0:
        try:
            buf = sock.recv(2**20)
        except Exception as error:
            raise TransportLayerException("Exception: {}".format(error))

        if len(buf) == 0:
            return data

        bytes_remain -= len(buf)
        data += buf

    return data


def get_end_of_header(message):
    return message.index(DELIM)


def get_start_of_body(message):
    return get_end_of_header(message) + len(DELIM)


def append_to_header(message, content):
    header = message[:get_end_of_header(message)] + "\r\n" + content + DELIM
    return header + message[get_start_of_body(message):]


def add_content_length(message):
    if "Content-Length: " not in message:
        contentlen = len(message[get_start_of_body(message):])
        message = append_to_header(message,
                                   "Content-Length: {}".format(contentlen))
    return message
