""" Implements functionality for seq2seq testing on CPU or GPU. """
from __future__ import print_function
import time
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import numpy as np
import tensorflow as tf
SEED=12345
tf.random.set_random_seed(SEED)

import datasets
import params
import ae_seq2seq


def test_ae(hps, args, dev='/cpu:0'):
    # Input tensor iterators.
    args.f = open(os.path.join(args.model_dir, "testing_logs.txt"), "a")
    input_iter = datasets.input_iterator(hps, args, 'test')
    iter_init = input_iter.initializer
    _, inputs_ast, outputs = input_iter.get_next()

    with tf.device(dev):
        # Build model.
        model = ae_seq2seq.Model(hps, inputs_ast, args.mode,
                                 char2int=datasets.restler_sequences.char2int,
                                 int2char=datasets.restler_sequences.int2char)
        model.build_graph()
        # Session configuration.
        config = tf.ConfigProto(allow_soft_placement=True)
        saver = tf.train.Saver()

        # Retrive metadata to calculate size of train set & iter for one epoch.
        size = 1000
        n_iter = max(1, int(size / hps.batch_size))
        print("testing: this should be from actual size", file=args.f)
        with tf.Session(config=config) as sess:
            try:
                ckpt_state = tf.train.get_checkpoint_state(args.model_dir)
            except Exception:
                print('Cannot restore checkpoint')
                return

            saver.restore(sess, ckpt_state.model_checkpoint_path)
            sess.run(iter_init)
            loss = .0
            accuracy = .0
            precision = .0
            recall = .0
            jaccard_coefficient = .0
            for _ in range(n_iter):
                rval = sess.run(model.loss)
                loss += rval
            cur_time = time.time()
            print("{}: Loss: {:.5f}".format(cur_time, loss/n_iter), file=args.f)
            args.f.close()
