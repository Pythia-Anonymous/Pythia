""" This module implements typical functionality for tensorflow
gradient-based neural network model instantiation and optimization.

We are just adding some extra functioncality for experimental exaluation and
Pythia-specific measurements. See function set_metrics.
"""
import numpy as np
import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)
import six
import math

from tensorflow.python.training import moving_averages


class Model(object):
    """ Base model base class. """
    def __init__(self, hps, inputs, outputs, mode,
                 external_trainable_variables):
        """Model constructor.

        Args:
          hps: Hyperparameters.
          inputs: Batches of inputs. [batch_size, input_size, 1]
          outputs: Batches of outputs. [batch_size, input_size, 1]
          mode: One of 'train' and 'eval'.
        """
        self.hps    = hps
        self.mode   = mode
        self.inputs = inputs
        self.outputs = outputs
        self.external_trainable_variables = external_trainable_variables

    def build_graph(self, inputs_tensor=None, outputs_tensor=None):
        """Build a whole graph for the model."""
        self.global_step = tf.contrib.framework.get_or_create_global_step()
        with tf.variable_scope('model_graph'):
            self._build_model(inputs_tensor, outputs_tensor)

        if self.mode == 'train':
            self._build_train_op()

    def _build_train_op(self):
        """Build training specific ops for the graph."""
        self.lrn_rte = tf.constant(self.hps.lrn_rte, tf.float32)

        trainable_variables = tf.trainable_variables()
        for var in self.external_trainable_variables:
            try:
                trainable_variables.remove(var)
            except ValueError:
                pass
        # When finetuning, keep everything but the last layer cconstant.
        grads = tf.gradients(self.loss, trainable_variables)

        if self.hps.optimizer == 'sgd':
            optimizer = tf.train.GradientDescentOptimizer(self.lrn_rte)
        elif self.hps.optimizer == 'mom':
            optimizer = tf.train.MomentumOptimizer(self.lrn_rte, 0.9)
        elif self.hps.optimizer == 'adam':
            optimizer = tf.train.AdamOptimizer(self.lrn_rte)

        apply_op = optimizer.apply_gradients(
            zip(grads, trainable_variables),
            global_step=self.global_step, name='train_step')

        previous_ops = [tf.group(*[apply_op])]
        with tf.control_dependencies(previous_ops):
            self.train_op = tf.no_op(name='train')

    def _conv(self, name, x, filter_size, in_filters, out_filters, stride):
        """Convolution, with support for sensitivity bounds when they are
        pre-noise."""
        with tf.variable_scope(name):
            n = filter_size * out_filters
            kernel = tf.get_variable(
                'DW', [filter_size, in_filters, out_filters],
                tf.float32, initializer=tf.random_normal_initializer(
                    stddev=np.sqrt(2.0 / n)
                )
            )
            return tf.nn.conv1d(x, kernel, stride, padding='SAME')

    def _relu(self, x, leakiness=0.0):
        """Relu, with optional leaky support."""
        return tf.where(tf.less(x, 0.0), leakiness * x, x, name='leaky_relu')

    def _fully_connected(self, x, out_dim):
      """FullyConnected layer."""
      x = tf.reshape(x, [self.hps.batch_size, -1])
      w = tf.get_variable(
          'DW', [x.get_shape()[1], out_dim],
          initializer=tf.uniform_unit_scaling_initializer(factor=1.0)
      )
      b = tf.get_variable('biases', [out_dim],
                          initializer=tf.constant_initializer())
      return tf.nn.xw_plus_b(x, w, b)

    def mse_loss(self, y_true, y_pred):
        return tf.losses.mean_squared_error(y_true, y_pred)

    def set_jaccard_coeff(self, y_true, y_pred, smooth=0.1):
        """ Calculates Jaccard distance as a loss function.

        Jaccard similarity is the ratio of true postives (tp) to the sum of
        true positives, false negatives (fn) and false positives (fp).
        """
        y_true = tf.to_float(y_true)
        tp = tf.reduce_sum(tf.math.multiply(y_true, y_pred), axis=1)
        fp = tf.reduce_sum(tf.math.multiply(y_true, 1.0 - y_pred), axis=1)
        fn = tf.reduce_sum(tf.math.multiply(1.0 - y_true, y_pred), axis=1)
        self.jaccard_coefficient = tf.math.divide(tp + smooth,
                                                  tp + fp + fn + smooth)
        self.jaccard_coefficient = tf.reduce_mean(self.jaccard_coefficient,
                                                 axis=0)
        return self.jaccard_coefficient

    def set_metrics(self, y_true, y_pred):
        """  Set up all metrics"""
        self.y_true = y_true
        self.y_pred = y_pred

        tp = tf.reduce_sum(tf.math.multiply(y_true, y_pred), axis=1)
        tn = tf.reduce_sum(tf.math.multiply(1.0 - y_true, 1.0 - y_pred), axis=1)
        fp = tf.reduce_sum(tf.math.multiply(y_true, 1.0 - y_pred), axis=1)
        fn = tf.reduce_sum(tf.math.multiply(1.0 - y_true, y_pred), axis=1)

        accuracy = tf.math.divide(tp + tn, tp + tn + fp + fn + 1e-10)
        self.accuracy = tf.reduce_mean(accuracy, axis=0)

        precision = tf.divide(tp, tp + fp + 1e-10)
        self.precision = tf.reduce_mean(precision, axis=0)

        recall = tf.divide(tp, tp + fn + 1e-10)
        self.recall = tf.reduce_mean(recall, axis=0)
        self.set_jaccard_coeff(y_true, y_pred)
