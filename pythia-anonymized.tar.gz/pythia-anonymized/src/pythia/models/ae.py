""" This module implements typical functionality for tensorflow
gradient-based neural network optimization."""
import numpy as np
import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)
from tensorflow.python.training import moving_averages


class Model(object):
    def __init__(self, hps, inputs, mode, char2int={}, int2char={}):
        """Model constructor.

        Args:
          hps: Hyperparameters.
          inputs: Batches of inputs. [batch_size, input_size, 1]
          mode: One of 'train' and 'eval'.
        """
        self.hps    = hps
        self.mode   = mode
        self.inputs = inputs
        self.targets = inputs
        self.char2int = char2int
        self.int2char = int2char

    def build_graph(self):
        """Build a whole graph for the model."""
        self.global_step = tf.contrib.framework.get_or_create_global_step()
        with tf.variable_scope('model_graph'):
            self._build_model()

        if self.mode == 'train':
            self._build_train_op()

    def _build_train_op(self):
        """Build training specific ops for the graph."""
        self.lrn_rte = tf.constant(self.hps.lrn_rte, tf.float32)

        trainable_variables = tf.trainable_variables()
        grads = tf.gradients(self.loss, trainable_variables)
        if self.hps.optimizer == 'sgd':
            optimizer = tf.train.GradientDescentOptimizer(self.lrn_rte)
        elif self.hps.optimizer == 'mom':
            optimizer = tf.train.MomentumOptimizer(self.lrn_rte, 0.9)
        elif self.hps.optimizer == 'adam':
            optimizer = tf.train.AdamOptimizer(self.lrn_rte)

        apply_op = optimizer.apply_gradients(
            zip(grads, trainable_variables),
            global_step=self.global_step, name='train_step')

        previous_ops = [tf.group(*[apply_op])]
        with tf.control_dependencies(previous_ops):
            self.train_op = tf.no_op(name='train')
