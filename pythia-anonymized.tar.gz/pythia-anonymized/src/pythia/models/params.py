"""Defines the parameters name tupple to pass to models.
"""
from collections import namedtuple


HParams = namedtuple('HParams',
                     'dataset,'
                     'batch_size,'
                     'input_size,'
                     'output_size,'
                     'lrn_rte,'
                     'relu_leakiness,'
                     'optimizer,'
                     'steps_num,'
                     'stride_size,'
                     'filter_size,'
                     'embedding_size,'
                     'rnn_size,'
                     'n_fully_connected,'
                     'n_filters,'
                     'eval_data_split')


def update(params, key, value):
    params = params._asdict()
    params[key] = value
    return HParams(**params)
