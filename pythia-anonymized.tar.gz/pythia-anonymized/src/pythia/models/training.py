""" Implements functionality for seq2seq training on CPU or GPU. """
from __future__ import print_function
import time
import os
import json
import numpy as np

import datasets
import params
import ae_seq2seq
import tensorflow as tf
SEED=12345
tf.random.set_random_seed(SEED)



def train_ae(hps, args, dev='/cpu:0'):
    # Input tensor iterators.
    args.f = open(os.path.join(args.model_dir, "training_logs.txt"), "a")
    input_iter = datasets.input_iterator(hps, args, 'train')
    iter_init = input_iter.initializer
    _, inputs_ast, _ = input_iter.get_next()

    with tf.device(dev):
        # Build model.
        model = ae_seq2seq.Model(hps, inputs_ast, 'train',
                                 char2int=datasets.restler_sequences.char2int,
                                 int2char=datasets.restler_sequences.int2char)
        model.build_graph()
        print("Finished building graph", file=args.f)

        # Session configuration.
        steps = 0
        config = tf.ConfigProto(allow_soft_placement=True)
        scaffold = tf.train.Scaffold(
            saver=tf.train.Saver(
                max_to_keep=1,
                save_relative_paths=True,
            )
        )

        # Handle the learning rates update mess
        class _LearningRateSetterHook(tf.train.SessionRunHook):
            """Sets learning_rate based on global step."""
            def begin(self):
                self._lrn_rte = hps.lrn_rte

            def before_run(self, run_context):
                return tf.train.SessionRunArgs(
                    model.global_step,
                    feed_dict={model.lrn_rte: self._lrn_rte}
                )

            def after_run(self, run_context, run_values):
                train_step = run_values.results

        # Start the main training loop.
        with tf.train.MonitoredTrainingSession(
            checkpoint_dir=args.model_dir,
            config=config,
            save_checkpoint_steps=100,
            hooks=[_LearningRateSetterHook()],
            scaffold=scaffold
        ) as mon_sess:
            mon_sess.run(iter_init)
            while steps < hps.steps_num:
                _, loss = mon_sess.run(
                    [
                        model.train_op,
                        model.loss,
                    ]
                )
		if steps % 100 == 0 or steps == 0:
                    cur_time = time.time()
                    print("{}: {}, {}".format(cur_time, steps, loss),
                          file=args.f)
                steps += 1
            args.f.close()
