""" This module implements an the cannonical tensorflow seq2seq model with input
embedding and no attention.

The code can be found in the tensorflow codebase where all seq2seq models
with input embeddings are defined. The only difference
introduced is the addition of a new tensor that allows to add perturbations on
the starting state of the decoder.
"""
from tensorflow.python.ops.rnn_cell import LSTMCell
import tensorflow as tf
import numpy as np
tf.logging.set_verbosity(tf.logging.ERROR)

import ae

from tensorflow.nn import rnn_cell
from tensorflow.python.layers.core import Dense
import numpy as np
import copy
from tensorflow.contrib.rnn.python.ops import core_rnn_cell


class Model(ae.Model):
    def __init__(self, hps, inputs, mode, char2int, int2char):
        ae.Model.__init__(self, hps, inputs, mode, char2int, int2char)

    def _build_model(self):
        _, encoder_state = self._encoding_layer()


        self.encoder_state = encoder_state
        self.mutated_encoder_state = tf.placeholder(
            tf.float32,
            shape=(self.hps.batch_size, self.hps.rnn_size)
        )

        if self.mode == 'fuzz':
            encoder_state = (self.mutated_encoder_state, )

        encoder_state = (tf.nn.sigmoid(encoder_state[0]), )

        dec_input = self._process_decoder_input()
        training_decoder_out, inference_decoder_out = self._decoding_layer(
            encoder_state, dec_input)

        training_logits = tf.identity(training_decoder_out.rnn_output, 'logits')
        inference_logits = tf.identity(inference_decoder_out.rnn_output,
                                       name='predictions')
        _  = tf.identity(encoder_state, name='encoder_state')

        masks = tf.sequence_mask(self.target_sequence_length,
                                 self.max_target_sequence_length,
                                 dtype=tf.float32,
                                 name='masks')
        with tf.name_scope("loss"):
            self.loss = tf.contrib.seq2seq.sequence_loss(
                training_logits,
                self.inputs,
                masks)

        self.outputs_train = training_logits
        self.outputs_inference = inference_logits

    def _encoding_layer(self):
        self.num_layers = 1
        num_layers = self.num_layers
        inputs = self.inputs
        rnn_size = self.hps.rnn_size
        batch_size = self.hps.batch_size
        encoding_embedding_size = self.hps.embedding_size

        self.max_source_sequence_length = tf.shape(self.inputs)[1]
        self.source_sequence_length = [self.max_source_sequence_length]*self.hps.batch_size
        source_vocab_size = len(self.char2int)
        enc_embed_input = tf.contrib.layers.embed_sequence(
            inputs, source_vocab_size, encoding_embedding_size
        )
        enc_cell = tf.contrib.rnn.MultiRNNCell(
            [tf.contrib.rnn.GRUCell(rnn_size) for _ in range(num_layers)]
        )
        initial_state = enc_cell.zero_state(batch_size, dtype=tf.float32)
        enc_output, encoder_state = tf.nn.dynamic_rnn(
            enc_cell,
            enc_embed_input,
            sequence_length=self.source_sequence_length,
            dtype=tf.float32,
            initial_state=initial_state
        )
        return enc_output, encoder_state

    def _process_decoder_input(self):
        batch_size = self.hps.batch_size
        target_data = self.inputs
        ending = tf.strided_slice(target_data, [0, 0],
                                  [batch_size, -1],
                                  [1, 1])
        dec_input = tf.concat([
            tf.fill([batch_size, 1], self.char2int['<GO>']), ending],
            1)
        return dec_input

    def _decoding_layer(self, encoder_state, dec_input):
        target_vocab_size = len(self.char2int)
        rnn_size = self.hps.rnn_size
        batch_size = self.hps.batch_size
        self.max_target_sequence_length = tf.shape(self.targets)[1]
        self.target_sequence_length = [self.max_target_sequence_length]*self.hps.batch_size
        dec_embeddings = tf.Variable(
            tf.random_uniform([target_vocab_size, self.hps.embedding_size])
        )
        dec_embed_input = tf.nn.embedding_lookup(dec_embeddings, dec_input)

        def make_cell(rnn_size):
            dec_cell = tf.contrib.rnn.GRUCell(
                rnn_size
            )
            return dec_cell

        dec_cell = tf.contrib.rnn.MultiRNNCell(
            [make_cell(rnn_size) for _ in range(self.num_layers)]
        )
        output_layer = Dense(
            target_vocab_size,
            kernel_initializer = tf.truncated_normal_initializer(mean = 0.0,
                                                                 stddev=0.1)
        )
        with tf.variable_scope("decode"):
            training_helper = tf.contrib.seq2seq.TrainingHelper(
                inputs=dec_embed_input,
                sequence_length=[self.max_target_sequence_length]*self.hps.batch_size,
                time_major=False
            )

            training_decoder = tf.contrib.seq2seq.BasicDecoder(dec_cell,
                                                               training_helper,
                                                               encoder_state,
                                                               output_layer)

            training_decoder_output = tf.contrib.seq2seq.dynamic_decode(
                training_decoder,
                impute_finished=True,
                maximum_iterations=self.max_target_sequence_length)[0]

        with tf.variable_scope("decode", reuse=True):
            start_tokens = tf.tile(
                tf.constant([self.char2int['<GO>']], dtype=tf.int32),
                [batch_size],
                name='start_tokens'
            )

            inference_helper = tf.contrib.seq2seq.GreedyEmbeddingHelper(
                dec_embeddings,
                start_tokens,
                self.char2int['<EOS>']
            )
            inference_decoder = tf.contrib.seq2seq.BasicDecoder(dec_cell,
                                                            inference_helper,
                                                            encoder_state,
                                                            output_layer)

            inference_decoder_output = tf.contrib.seq2seq.dynamic_decode(
                inference_decoder,
                impute_finished=True,
                maximum_iterations=self.max_target_sequence_length)[0]

        return training_decoder_output, inference_decoder_output
