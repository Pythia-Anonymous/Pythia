""" Static analysis module to extract basic block edges. The logic for
extracting basic blogs is similar to what is implemented for AFL
(described here: https://lcamtuf.coredump.cx/afl/technical_details.txt)
adjusted to an interpreted language.

Usage: python extract_basic_block_edges.py /home/git/gitlab/app

Explanation: The above will extract all basic blocks defined in source code
files under the folder "/home/git/gitlab/app" and generate a file named
"basic_block_edges.json" which will contain a json dictionary whose keys will be
file name hashes and the values for each key will be a list of basic block
tuples. Usually, this static analysis pass takes some time (depending on the
size of the codebase) but it needs to happen only once ;-).
"""
from __future__ import print_function
import os
import sys
import json
import hashlib
import subprocess


def instrument_source_code(filename):
    """ Returns a list of all branching points in a file. """

    # Use the ruby parser to get AST representation
    out = subprocess.Popen(['ruby', '--dump', 'parsetree', filename],
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT)

    stdout, stderr = out.communicate()
    stdout = stdout.split("\n")

    lc = 0
    func_id = -1
    branch_points = []

    # Skip preables and go directly to function definitions
    while lc < len(stdout):
        line = stdout[lc]
        if 'NODE_DEFN' in line:
            break
        lc += 1

    # Main loop
    while lc < len(stdout):
        line = stdout[lc]
        # Handle function definitions
        if 'NODE_DEFN' in line:
            func_id += 1
            branch_points.append([])
            lc += 1

        # Handle openings of if/unless nodes
        elif "@ NODE_IF" in line or "@ NODE_UNLESS" in line:
            branch_line = int(str(line).strip("\n").split("line: ")[1].split(",")[0])
            while 'nd_body:' not in stdout[lc]:
                lc += 1
            line = stdout[lc + 1]
            if not "(null node)" in line:
                body_line = int(str(line).split("line:")[1].split(",")[0])
                branch_points[func_id].append(("IF",branch_line, body_line))
            lc += 1

        # Handle else
        elif line.endswith("+- nd_else:"):
            lc += 1
            line = stdout[lc]
            if "(null node)" in line:
                branch_line = -1
                body_line  = -1
            else:
                branch_line = -1
                body_line = int(str(line).split("line:")[1].split(",")[0])
            branch_points[func_id].append(("ELSE", branch_line, body_line))
            # Don't consume line if and "IF" opens here
            if "@ NODE_IF" not in line and "@ NODE_UNLESS" not in line:
                lc += 1
        else:
            lc += 1

    return branch_points


def construct_edges(branch_points):
    """ Traverses the list of branches and produces the respective edges. """
    if not branch_points:
        return

    i = 0
    edges = []
    while i < len(branch_points):
        a = branch_points[i]
        if a[0] == 'IF':
            # Handles if
            edges.append((a[1], a[2]))
            i += 1
        else:
            a = branch_points[i-1]
            b = branch_points[i]
            # ELSE w/o body: do nothing, just skip and continue
            if b[2] == -1:
                i += 1
            # ELSE w/ body
            else:
                edges.append((a[1], b[2]))
                del branch_points[i-1]
                del branch_points[i-1]
                i -= 1

    return edges


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage {}: <dir>".format(sys.argv[0]))
        sys.exit(-1)

    # Get all ruby source code files in each directory given as argument
    edges = {}
    total_files = 0
    skipped_files = []
    for i in range(1, len(sys.argv)):

        # Get all ruby source code files in the current directory.
        root = sys.argv[i]
        filenames = [os.path.join(path, name)
                     for path, subdirs, files in os.walk(root) for name in files
                     if name.endswith(".rb")]

        # For each file:
        #   1) Get branching points
        #   2) Construct respective edges
        for count, filename in enumerate(sorted(filenames)):
            print("{}/{}: {}".format(count + 1, len(filenames), filename))
            # Hash the filename to save some space.
            hash_object = hashlib.sha1(filename)
            filename_hash = hash_object.hexdigest()[:10]
            edges[filename_hash] = []
            branch_points = instrument_source_code(filename)
            for func in branch_points:
                try:
                    current_edges = construct_edges(func)
                    if current_edges:
                        edges[filename_hash].extend(current_edges)
                except IndexError:
                    print("Skipping a function from file: {}".format(filename))
                    skipped_files.append(filename)

        total_files += len(filenames)

    print("Skipped files: {}".format(skipped_files))
    print("Processed {} source code files in total".format(total_files))
    print("Found {} basic block edges".format(sum(map(len, edges.values()))))

    # Save dictionary of edges
    with open('/tmp/basic_block_edges.json', 'w') as f:
        json.dump(edges, f)

    print("Saved dictionary at {}".format('/tmp/basic_block_edges.json'))
