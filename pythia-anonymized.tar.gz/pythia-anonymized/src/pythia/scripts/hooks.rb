sock = UNIXSocket.new("/tmp/coverage_sock")
TracePoint.new(:line) do |tp|
    microSec = Time.now.to_f * 1000**2
    microSec = microSec.to_i
    log_msg =  "%d:%s:%d\n" % [microSec, tp.path, tp.lineno]
    sock.puts log_msg
end
