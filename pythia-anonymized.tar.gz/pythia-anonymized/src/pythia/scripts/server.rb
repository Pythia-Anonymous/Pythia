# Socket server storing coverage information from the target service.
require 'date'
require 'socket'
require 'set'
require 'json'
require 'digest/sha1'

# Init listening server
SOCK='/tmp/coverage_sock'
LOGS='/tmp/coverage_stats.txt'
File.open(LOGS, 'w') {}
serv = UNIXServer.new(SOCK)
coverageDict = Hash.new
cumulative_lcov = 0

while true
    s = serv.accept
    f = File.open(LOGS, 'a')
    while(line = s.gets) do
        ts, filename, lineno = line.strip.split(':')
        # Hash the filename and keep the 10 first bytes to save some space.
        filename_hash = Digest::SHA1.hexdigest filename
        filename_hash = filename_hash.to_s
        filename = filename_hash[0..9]
        # This is another optimization: skip common basepath -- not used
        # filename = filename[17..]

        if not coverageDict.key?(filename)
            coverageDict[filename] = Set.new
        end
        if not coverageDict[filename].include?  lineno
            coverageDict[filename].add lineno
            cumulative_lcov += 1
        end
        f.puts "%d:%s:%d:%d" % [ts, filename, lineno, cumulative_lcov]
        f.flush()
   end
end

