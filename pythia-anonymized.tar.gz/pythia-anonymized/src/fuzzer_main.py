""" Main application entry point for Pythia fuzzer.


usage: fuzzer_pythia.py [-h] [--model_dir_ae MODEL_DIR_AE]
                        [--distillation DISTILLATION] [--n_seeds N_SEEDS]
                        [--gc_interval GC_INTERVAL]
                        [--time_budget TIME_BUDGET]
                        [--max_mutations_per_production_rule MAX_MUTATIONS_PER_PRODUCTION_RULE]
                        [--n_adversarial_steps N_ADVERSARIAL_STEPS]
                        [--adversarial_attack_bound ADVERSARIAL_ATTACK_BOUND]
                        [--max_mutations_per_seed_edge MAX_MUTATIONS_PER_SEED_EDGE]
                        [--target_ip TARGET_IP] [--target_port TARGET_PORT]
                        [--start_time START_TIME] [--log_file LOG_FILE]
                        [--feedback_mode FEEDBACK_MODE]

optional arguments:
  -h, --help            show this help message and exit
  --model_dir_ae MODEL_DIR_AE
                        Directory of the trained model
  --dataset DATASET     <seq, edges> pairs
  --distillation DISTILLATION
  --n_seeds N_SEEDS     Seed to fuzz
  --gc_interval GC_INTERVAL
                        Period of GC (seconds)
  --time_budget TIME_BUDGET
                        Time out (hours)
  --max_mutations_per_production_rule MAX_MUTATIONS_PER_PRODUCTION_RULE
                        Max mutations per payload rule
  --n_adversarial_steps N_ADVERSARIAL_STEPS
                        Adversarial steps
  --adversarial_attack_bound ADVERSARIAL_ATTACK_BOUND
                        Adversarial steps
  --max_mutations_per_seed_edge MAX_MUTATIONS_PER_SEED_EDGE
                        Max number of mutations per seed
  --target_ip TARGET_IP
                        Service IP
  --target_port TARGET_PORT
                        Service Port
  --start_time START_TIME
                        Fuzzing start time
  --log_file LOG_FILE   Fuzzing start time
  --feedback_mode FEEDBACK_MODE
                        Use of feedback
"""
from __future__ import print_function
import os
import sys
import time
import shutil
import argparse
import json
import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)

import datasets
from pythia.utils import seeds
from pythia.utils import fuzzing_ops
from pythia.models import params
from pythia.models import ae_seq2seq


def print_fuzzing_stats(args):
    time_stats = {}
    args.total_time = int(int(time.time()*10**6) - args.start_time)
    time_stats['total_time'] = args.total_time
    args.other_ops_time = args.total_time\
        - args.fuzzing_ops_time
    time_stats['other_ops_time'] = args.other_ops_time
    time_stats['network_ops_time'] = args.network_ops_time
    time_stats['gradient_ops_time'] = args.gradient_ops_time
    time_stats['model_preloading_time'] = args.model_preloading_time
    time_stats['fuzzing_ops_time'] = args.fuzzing_ops_time\
        - args.network_ops_time - args.gradient_ops_time\
        - args.model_preloading_time
    print("MARKER_TIMING:", json.dumps(time_stats), file=args.f)
    print("MARKER_STATUS_CODES:", json.dumps(args.status_codes), file=args.f)
    print("MARKER_NETWORK_EXCEPTIONS:",
        json.dumps({'Exceptions': args.exceptions, 'Sucesses': args.successes}),
        file=args.f
    )


def fuzz(hps, args, dev="/cpu:0"):
    """ This function implements the main loop that iterates over available
    seeds and performs learning-based mutations and execution of new sequences.
    """
    t1 = int(time.time()*10**6)
    config = tf.ConfigProto(allow_soft_placement=True)
    sess = tf.Session(config=config)

    fuzzing_ops.set_latest_model_ts(args)
    print(args, file=args.f)
    print(hps, file=args.f)

    # Resetting the training lines buffer will force the input iterator to
    # re-read the (augmented) dataset every time the current function is re-run.
    datasets.restler_sequences.input_iterator.dataset = []

    # This will force the seed loader to re-distill and re-load in memory seeds
    # from the augmented dataset.
    seeds.select_random_seed.seeds = {}
    seeds.select_random_seed.last_seed_i = 0

    # This will force the seed loader to re-load the new production rules.
    datasets.reconstruct_sequence_from_ast.production_rules = {}

    # This will force the fuzzer, after reloading a fresh model, to reconsider
    # pertubations on seeds that had been black listed because the previous
    # model couldn't yield any mutations.
    fuzzing_ops.do_fuzzing_stacked.seeds_cache = {}

    # This will force tf to re-add the gradients calculation op to the graph.
    fuzzing_ops.do_fuzzing_stacked.grad_op = None

    input_iter = datasets.input_iterator(hps, args, 'fuzz')
    iter_init = input_iter.initializer
    inputs_raw, inputs_ast, outputs = input_iter.get_next()

    # Just invoke the function to construct the internal indices in order to
    # retrieve the id of <PAD> symbol.
    try:
        datasets.reconstruct_sequence_from_ast(None, hps)
    except Exception:
        pass

    with tf.device(dev):
        model_ae = ae_seq2seq.Model(
            hps, inputs_ast, 'fuzz',
            char2int=datasets.restler_sequences.char2int,
            int2char=datasets.restler_sequences.int2char
        )
        model_ae.build_graph()
        ae_variables = set(tf.all_variables())
        ae_saver = tf.train.Saver(ae_variables)
        try:
            ae_ckpt_state = tf.train.get_checkpoint_state(args.model_dir_ae)
            ae_saver.restore(sess, ae_ckpt_state.model_checkpoint_path)
            print("Finished restoring ae:", ae_ckpt_state.model_checkpoint_path,
                  file=args.f)
        except tf.errors.OutOfRangeError as e:
            assert False

        sess.run(iter_init)
        args.model_preloading_time = int(time.time()*10**6) - t1
        i = 0
        while True:
            i += 1
            sequence_raw, sequence_ast, bitmap = seeds.select_random_seed(
                hps, args, sess, inputs_raw, inputs_ast, outputs)
            fuzzing_ops.do_fuzzing_stacked(hps, args, sess, model_ae,
                                           sequence_ast, bitmap)
            print("{}: Reload-{}: Finished Seed {})".\
                  format(int(time.time()*10**6), args.reloads,
                         i + 1), file=args.f)
            should_reload = fuzzing_ops.is_current_model_outdated(args)\
                and fuzzing_ops.is_latest_model_complete(args)
            print("Should reload model: {}\n\n".format(should_reload),
                  file=args.f)
            if should_reload:
                # Raise exception to restart current fuction in outer loop.
                raise fuzzing_ops.OutdatedModelException("New model available")

            args.f.flush()

        raise fuzzing_ops.OutOfSeedsException("Run out of seeds")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_dir_ae', help='Directory of the trained model',
                        type=str)
    parser.add_argument('--dataset', help='<seq, edges> pairs',
                        type=str)
    parser.add_argument('--distillation', type=str, default='on')
    parser.add_argument('--n_seeds', help='Seed to fuzz', type=int, default=2)
    parser.add_argument('--gc_interval',help='Period of GC (seconds)',
                        type=int, default=10)
    parser.add_argument('--time_budget', help='Time out (hours)', type=float,
                        default=1.0)
    parser.add_argument('--max_mutations_per_production_rule',
                        help='Max mutations per payload rule', type=int,
                        default=3)
    parser.add_argument('--n_adversarial_steps',
                        help='Adversarial steps', type=int,
                        default=10)
    parser.add_argument('--adversarial_attack_bound',
                        help='Adversarial steps', type=float,
                        default=0.1)
    parser.add_argument('--max_mutations_per_seed_edge',
                        help='Max number of mutations per seed', type=int,
                        default=1000)
    parser.add_argument('--target_ip', help='Service IP', type=str,
                        default='localhost')
    parser.add_argument('--target_port', help='Service Port', type=int,
                        default=80)
    parser.add_argument('--start_time', help='Fuzzing start time', type=int)
    parser.add_argument('--log_file', help='Fuzzing start time', type=file)
    parser.add_argument('--feedback_mode', help='Use of feedback', type=str,
                        default='gradients')
    args  = parser.parse_args()

    # Train or test and some other argument conflict checks.
    assert args.model_dir_ae
    assert args.dataset
    assert args.feedback_mode in ['gradients', 'random']

    args.exceptions = 0
    args.reloads = 0
    args.successes = 0
    args.total_time = 0
    args.model_preloading_time = 0
    args.network_ops_time = 0
    args.gradient_ops_time = 0
    args.other_ops_time = 0
    args.fuzzing_ops_time = 0
    args.status_codes = {}
    args.start_time = int(time.time()*10**6)
    args.time_budget = int(args.time_budget*3600*10**6)
    args.f = open(os.path.join(os.path.dirname(args.model_dir_ae),
                  "fuzzing_logs_{}.txt".format(args.feedback_mode)), "w")
    #args.f = sys.stdout

    config_file_ae = [os.path.join(args.model_dir_ae ,x)
                      for x in os.listdir(args.model_dir_ae)
                      if x.endswith("config_ae.json")]
    assert len(config_file_ae) == 1
    config_file_ae = json.loads(open(config_file_ae[0], "r").read())

    try:
        stride_size = 0
        filter_size = 0
        n_filters = 0
        embedding_size = int(config_file_ae['embedding_size'])
        rnn_size = int(config_file_ae['rnn_size'])
        batch_size = int(config_file_ae['batch_size'])
        input_size = int(config_file_ae['input_size'])
        output_size = int(config_file_ae['output_size'])
        lrn_rate = float(config_file_ae['lrn_rte'])
        relu_leakiness = float(config_file_ae['relu_leakiness'])
        optimizer = str(config_file_ae['optimizer'])
        steps_num = int(config_file_ae['steps_num'])
        eval_data_split = float(config_file_ae['eval_data_split'])
    except Exception as error:
        raise
        print("Exception parsing config file:", error, args.f)
        sys.exit(-1)

    hps = params.HParams(
            batch_size=batch_size,
            input_size=input_size,
            output_size=output_size,
            lrn_rte=lrn_rate,
            relu_leakiness=relu_leakiness,
            optimizer=optimizer,
            stride_size=stride_size,
            filter_size=filter_size,
            n_filters=n_filters,
            n_fully_connected=0,
            embedding_size=embedding_size,
            rnn_size=rnn_size,
            steps_num=steps_num,
            eval_data_split=eval_data_split,
            dataset=args.dataset
    )
    t1 = int(time.time()*10**6)
    while True:
        try:
            with tf.Graph().as_default():
                fuzz(hps, args, dev="/gpu:0")
        except fuzzing_ops.TimeOutException:
            print("Time budget just expired.", file=args.f)
            break
        except fuzzing_ops.OutOfSeedsException:
            print("Run out of seeds.", file=args.f)
            break
        except fuzzing_ops.OutdatedModelException:
            # Update the path from which the (augmented) new dataset
            # must be read.
            hps = fuzzing_ops.set_latest_dataset_hps(hps)
            args.reloads += 1

    args.fuzzing_ops_time += int(time.time()*10**6) - t1
    print_fuzzing_stats(args)
    args.f.close()
