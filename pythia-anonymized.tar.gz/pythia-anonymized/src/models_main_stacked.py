from __future__ import print_function
import os
import sys
import time
import shutil
import argparse
import json
import glob
import random
SEED=12345
random.seed(SEED)

import models


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--distillation', type=str, default='on')
    parser.add_argument('--mode', help='Mode (train or test)', type=str)
    parser.add_argument('--model_dir_ffwd',
                        help='Directory of the trained model',
                        type=str)
    parser.add_argument('--config_file_ffwd', help='Configuration file',
                        type=str)
    parser.add_argument('--model_dir_ae', help='Directory of the trained model',
                        type=str)
    parser.add_argument('--dataset', help='RESTler <seq, edges> pairs',
                        type=str)
    parser.add_argument('--median_percentile', help='Calibration threashold', type=int,
                        default=75)
    args  = parser.parse_args()

    # Train or test and some other argument conflict checks.
    assert (args.mode == 'train' or args.mode == 'test')
    assert args.model_dir_ffwd
    assert args.model_dir_ae
    if args.mode == 'train':
        assert args.config_file_ffwd
    else:
        assert not args.config_file_ffwd
    assert args.dataset

    config_file_ae = [os.path.join(args.model_dir_ae ,x)
                      for x in os.listdir(args.model_dir_ae)
                      if x.endswith(".json")]
    assert len(config_file_ae) == 1
    config_file_ae = json.loads(open(config_file_ae[0], "r").read())
    if args.mode == 'train':
        config_file_ffwd = json.loads(open(args.config_file_ffwd, "r").read())
    else:
        config_file_ffwd = [os.path.join(args.model_dir_ffwd ,x)
                            for x in os.listdir(args.model_dir_ffwd)
                            if x.endswith(".json")]
        assert len(config_file_ffwd) == 1
        config_file_ffwd = json.loads(open(config_file_ffwd[0], "r").read())

    # Load configuration.
    try:
        stride_size = 0
        filter_size = 0
        n_filters = 0
        embedding_size = int(config_file_ae['embedding_size'])
        batch_size = int(config_file_ae['batch_size'])
        input_size = int(config_file_ae['input_size'])
        output_size = int(config_file_ae['output_size'])
        lrn_rate = float(config_file_ae['lrn_rte'])
        relu_leakiness = float(config_file_ae['relu_leakiness'])
        optimizer = str(config_file_ae['optimizer'])
        rnn_size = int(config_file_ae['rnn_size'])
        n_fully_connected = int(config_file_ffwd['n_fully_connected'])
        steps_num = int(config_file_ffwd['steps_num'])
        eval_data_split = float(config_file_ae['eval_data_split'])
    except Exception as error:
        print("Exception parsing config file:", error)
        sys.exit(-1)

    # Initialize hyperparms.
    hps = models.params.HParams(
            batch_size=batch_size,
            input_size=input_size,
            output_size=output_size,
            lrn_rte=lrn_rate,
            relu_leakiness=relu_leakiness,
            optimizer=optimizer,
            stride_size=stride_size,
            filter_size=filter_size,
            n_filters=n_filters,
            embedding_size=embedding_size,
            n_fully_connected=n_fully_connected,
            rnn_size=rnn_size,
            steps_num=steps_num,
            eval_data_split=eval_data_split,
            dataset=args.dataset
    )
    print(hps)
    # Copy config file to model's folder.
    if args.mode == 'train':
        # Base folder
        if not os.path.exists(args.model_dir_ffwd):
            os.mkdir(args.model_dir_ffwd)
        target_dir = str(args.model_dir_ffwd)

        # Indermediate folder for partially trainned models.
        args.model_dir_ffwd = os.path.join(
            args.model_dir_ffwd,
            ".model_{}".format(int(time.time()))
        )
        os.mkdir(args.model_dir_ffwd)
        shutil.copyfile(args.config_file_ffwd,
                        os.path.join(args.model_dir_ffwd,
                                     os.path.basename(args.config_file_ffwd)
                                    )
                        )
    print(args)
    if args.mode == 'train':
        models.training.train_stacked(hps, args, dev="/gpu:0")
        # When training is over, copy the finished model back.
        for filename in glob.glob(os.path.join(args.model_dir_ffwd, '*')):
            shutil.copy(filename, target_dir)
        # Mark copying complete.
        open(os.path.join(args.model_dir_ffwd, "copying_complete"), "w+").close()
    else:
        models.testing.test_stacked(hps, args, dev="/gpu:0")
