#!/bin/bash

target_hash="cac489b42f0ad7f05a18bb8daf2fefe17992be1a"
sudo bash -c "echo 3 > /proc/sys/vm/drop_caches"
sudo rm /tmp/coverage_sock
sudo rm /tmp/coverage_stats.txt
for f in `/bin/ls /home/git/gitlab/log/*.log`; do
    sudo bash -c "echo '' > ${f}"
done
sudo bash -c "echo 3 > /proc/sys/vm/drop_caches"
while true;
do
    sudo su git<<'EOF'
sleep 1
echo "Killing python"
for i in `pgrep python`; do
    kill -9 $i
done
sleep 5
pushd /home/git/gitlab
echo "Removing UNIX socker and coverage file"
sleep 1
echo "Killing unicorn workers"
pgrep "ruby"
if [ $? ]; then
    echo "unicorn workers:"
    kill -9 `pgrep "ruby"`
fi
echo "Starting coverage server"
ruby ~/repos/apifuzz/src/scripts/server.rb &
echo "cleaning DB"
psql -d gitlabhq_production -c "DELETE from projects"
echo "cleaning repos"
for r in `/bin/ls /home/git/repositories/root`; do
    rm -rf /home/git/repositories/root/$r
done
echo "Restarting GitLab"
/etc/init.d/gitlab restart
sleep 10
popd
EOF
    echo "Setting up finished!"
    echo "Checking starting point"
    current_hash=`cat /tmp/coverage_stats.txt  | cut -f2,3 -d':'| sort | sha1sum | sed 's, .*,,g'`
    echo "$current_hash"
    echo "$target_hash"
    if [ "$current_hash" == "$target_hash" ]; then
        break
    fi
    break
done
cp /tmp/coverage_stats.txt /tmp/boot_coverage_stats.txt
echo "Good to go..."
echo ""
