#!/bin/bash

rm /tmp/coverage_sock
echo "" > /tmp/coverage_stats.txt
echo "" > ~/spree/sandbox/log/development.log
sudo bash -c "echo 3 > /proc/sys/vm/drop_caches"

sleep 3
echo "Killing python"
for i in `pgrep python`; do
    kill -9 $i
done

echo "Killing ruby"
for i in `pgrep ruby`; do
    kill -9 $i
done


sleep 3
echo "Killing puma workers"
for i in `ps -FALL | grep puma | grep -v "grep" | cut -f2 -d' '`; do
    kill -9 $i
done

echo "Delete DB"
sqlite3 -line ~/spree/sandbox/db/development.sqlite3 'delete from spree_oauth_access_tokens;'

echo "Starting coverage server"
ruby ~/repos/apifuzz/src/scripts/server.rb &
sleep 5

echo "Starting Spree"
bash<<'EOF'
cd ~/spree/sandbox
rails server -b 0.0.0.0 > /dev/null &
cd -
EOF
sleep 40

cp /tmp/coverage_stats.txt /tmp/boot_coverage_stats.txt
echo "Good to go..."
