#!/bin/bash

sudo rm /tmp/coverage_sock
sudo rm /tmp/coverage_stats.txt
for f in `/bin/ls /home/git/gitlab/log/*.log`; do
    sudo bash -c "echo '' > ${f}"
done
sudo bash -c "echo 3 > /proc/sys/vm/drop_caches"

sudo su mastodon<<'EOF'
sleep 1
echo "Killing python"
for i in `pgrep python`; do
    kill -9 $i
done

sleep 1
echo "Killing puma workers"
pgrep "puma"
if [ $? ]; then
    echo "puma workers:"
    kill -9 `pgrep "puma"`
fi

echo  "Cleaning DB"
psql -d mastodon_production -c "DELETE from oauth_access_tokens where token NOT IN  ('WI4i6M3m662dBteX_jtPTcqnR7pKotvg5V68oeVrMqE', 'ymceDaQp1F1rNc8H00gJkIWr2N6jwZ1BO4P3k2EBlGw')"
psql -d mastodon_production -c "DELETE from accounts where username NOT IN ('admin', 'example.com')"
psql -d mastodon_production -c "DELETE from statuses"
psql -d mastodon_production -c "DELETE from notifications"
psql -d mastodon_production -c "DELETE from conversations"
psql -d mastodon_production -c "DELETE from polls"
psql -d mastodon_production -c "DELETE from lists"
psql -d mastodon_production -c "DELETE from users where id <> 1"
psql -d mastodon_production -c "DELETE from account_stats where account_id <> 1"


echo "Starting coverage server"
ruby ~/repos/apifuzz/src/scripts/server.rb &
EOF

echo "Restarting Mastodon"
sudo systemctl stop  mastodon-web mastodon-sidekiq mastodon-streaming
sleep 5
sudo systemctl start mastodon-web mastodon-sidekiq mastodon-streaming
sleep 45

cp /tmp/coverage_stats.txt /tmp/boot_coverage_stats.txt
echo "Good to go..."
