""" Main entry point for setting up model training. """
from __future__ import print_function
import os
import sys
import time
import shutil
import argparse
import json
import glob
import random
SEED=12345
random.seed(SEED)

import pythia.models


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', help='Mode (train or test)', type=str)
    parser.add_argument('--distillation', type=str, default='off')
    parser.add_argument('--config_file', help='Configuration file', type=str)
    parser.add_argument('--model_dir', help='Directory of the trained model',
                        type=str)
    parser.add_argument('--dataset', help='RESTler <seq, edges> pairs',
                        type=str)
    parser.add_argument('--median_percentile', help='Calibration threashold', type=int,
                        default=75)
    args  = parser.parse_args()

    # Train or test and some other argument conflict checks.
    assert (args.mode == 'train' or args.mode == 'test' or args.mode == 'fuzz')
    assert args.model_dir
    assert args.dataset

    # When training config file path is specified; when testing config file
    if args.mode == 'train':
        assert args.config_file
        config = json.loads(
            open(os.path.join(os.getcwd(), args.config_file), "r").read()
        )
    else:
        assert (not args.config_file)
        model_dir = os.path.join(os.getcwd(), args.model_dir)
        config_file = [os.path.join(model_dir ,x) for x in os.listdir(model_dir)
                       if x.endswith(".json")]
        assert len(config_file) == 1
        config = json.loads(open(config_file[0], "r").read())

    # Load configuration.
    try:
        stride_size = 0
        filter_size = 0
        n_filters = 0
        n_fully_connected = 0
        embedding_size = int(config['embedding_size'])
        batch_size = int(config['batch_size'])
        input_size = int(config['input_size'])
        output_size = int(config['output_size'])
        lrn_rate = float(config['lrn_rte'])
        relu_leakiness = float(config['relu_leakiness'])
        optimizer = str(config['optimizer'])
        rnn_size = int(config['rnn_size'])
        steps_num = int(config['steps_num'])
        eval_data_split = float(config['eval_data_split'])
    except Exception as error:
        print("Exception parsing config file:", error)
        sys.exit(-1)

    # Initialize hyperparms.
    hps = pythia.models.params.HParams(
            batch_size=batch_size,
            input_size=input_size,
            output_size=output_size,
            lrn_rte=lrn_rate,
            relu_leakiness=relu_leakiness,
            optimizer=optimizer,
            stride_size=stride_size,
            filter_size=filter_size,
            n_filters=n_filters,
            embedding_size=embedding_size,
            n_fully_connected=n_fully_connected,
            rnn_size=rnn_size,
            steps_num=steps_num,
            eval_data_split=eval_data_split,
            dataset=args.dataset
    )
    print(hps)
    # Copy config file to model's folder.
    if args.mode == 'train':
        # Base folder
        if not os.path.exists(args.model_dir):
            os.mkdir(args.model_dir)
        target_dir = str(args.model_dir)

        # Indermediate folder for partially trainned models.
        args.model_dir = os.path.join(
            args.model_dir,
            ".model_{}".format(int(time.time()))
        )
        os.mkdir(args.model_dir)
        shutil.copyfile(args.config_file,
                        os.path.join(args.model_dir,
                                     os.path.basename(args.config_file)
                                    )
                        )
    print(args)
    if args.mode == 'train':
        pythia.models.training.train_ae(hps, args, dev="/gpu:0")
        # When training is over, copy the finished model back.
        for filename in glob.glob(os.path.join(args.model_dir, '*')):
            shutil.copy(filename, target_dir)
        # Mark copying complete.
        open(os.path.join(args.model_dir, "copying_complete"), "w+").close()
    else:
        pythia.models.testing.test_ae(hps, args, dev="/gpu:0")
