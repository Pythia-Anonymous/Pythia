from datasets import restler_sequences
from restler_sequences import reconstruct_sequence_from_ast
from restler_sequences import reconstruct_sequence_raw
from restler_sequences import SequenceReconstructionException
from restler_sequences import char2int
from restler_sequences import int2char
from restler_sequences import revert
from restler_sequences import remove_padding_and_add_eos


def input_iterator(hps, args, mode, verbose=False):
    try:
        return restler_sequences.input_iterator(hps, args, mode,
                                                verbose=verbose)
    except Exception, error:
        print("Dateset error:", error)
        raise
