""" Implements key functionality to process seed input datasets
produced by RESTler.
"""
from __future__ import print_function
SEED=12345
import json
import random
random.seed(SEED)
import numpy as np
np.random.seed(SEED)
import tensorflow as tf
from types import FunctionType
tf.random.set_random_seed(SEED)


# Global dictionaries to map production rules to seq2seq model input symbols
char2int = {}
int2char = {}


class SequenceReconstructionException(Exception):
    """ Exception raised when sequence cannoot be reconstructed. """
    pass


def do_calibration(dataset, args, mode):
    """ Helper to do calibration of the dataset.

    This helps avoid overfitting very long sequences that have minor differences
    (in terms of production rules) and all exercise the same execution path.
    Since RESTler, or any other tool that performs a systematic state space
    exploration, will get stuck in an inevitable combinatorial explosion, one
    may want to have a way to calibrate the distibution of redundant sequences
    accoring to their length before constructing a dataset.

    @param dataset: The sequences of the dataset
    @type  dataset: List of tuples
    @param args: Command line arguments
    @type  args: ArgumentParser
    @param mode: Argument controlling training, testing, or fuzzing
    @type  mode: Str

    @return: The calibrated dataset
    @rtype:  List
    """
    bitmap_buckets = {}
    for seq in dataset:
        bitmap = seq[1]
        bitmap = tuple([i for i, x in enumerate(bitmap) if x == '1'])
        if bitmap not in bitmap_buckets:
            bitmap_buckets[bitmap] = 0
        bitmap_buckets[bitmap] += 1

    # Traverse the distribution of sequence lengths and keep the smallest
    keep = []
    for b1 in bitmap_buckets.keys():
        _b1 = set(b1)
        skip = False
        for b2 in keep:
            _b2 = set(b2)
            if len(_b1.union(_b2)) == max(map(len, [_b1, _b2])):
                skip = True
                break
        if not skip:
            keep.append(b1)

    # Shuffle when training
    if mode != 'fuzz' or args.distillation == "on":
        np.random.shuffle(dataset)

    # If distillation is on, only keep shortest sequence exercising a path
    if args.distillation == "on":
        median = 1
        print("Value:", median, file=args.f)
        print("Buckets before calibration:", bitmap_buckets.values(), file=args.f)

        bitmap_buckets = {}
        calibrated_dataset = []
        for seq in dataset:
            bitmap = seq[1]
            bitmap = tuple([i for i, x in enumerate(bitmap) if x == '1'])
            if not bitmap in bitmap_buckets:
                bitmap_buckets[bitmap] = 0
            if bitmap in keep and bitmap_buckets[bitmap] < median:
                calibrated_dataset.append(seq)
                bitmap_buckets[bitmap] += 1

        print("Buckets after calibration:", bitmap_buckets.values(), file=args.f)
        print("Actual size:", len(calibrated_dataset), file=args.f)
        return calibrated_dataset
    # If distillation is off, keep all sequences up to a certain percentile per
    # execution path, and then truncate the distribution
    else:
        if mode != 'fuzz':
            median = np.percentile(bitmap_buckets.values(), args.median_percentile)
        else:
            median = 10**6
        print("Value:", median, file=args.f)
        print("Buckets before calibration:", bitmap_buckets.values(), file=args.f)

        bitmap_buckets = {}
        calibrated_dataset = []
        for seq in dataset:
            bitmap = seq[1]
            bitmap = tuple([i for i, x in enumerate(bitmap) if x == '1'])
            if not bitmap in bitmap_buckets:
                bitmap_buckets[bitmap] = 0
            if bitmap_buckets[bitmap] < median or mode != 'train':
                calibrated_dataset.append(seq)
                bitmap_buckets[bitmap] += 1

        print("Buckets after calibration:", bitmap_buckets.values(), file=args.f)
        print("Actual size:", len(calibrated_dataset), file=args.f)
        return calibrated_dataset


def make_indices(input_iterator):
    """ Typical helper making forwads and inverse dictionaries for seq2seq
    models.
    """
    global char2int, int2char

    special_words = ['<PAD>', '<UNK>', '<GO>',  '<EOS>']
    all_lines =  input_iterator.dataset
    all_lines = map(lambda x: x[2], all_lines)
    set_words = set([char for line in all_lines for char in line])
    int2char = {word_i: word
                for word_i, word in enumerate(list(set_words) + special_words)}
    char2int = {word: word_i for word_i, word in int2char.items()}


def decode_input(line, input_size, padding=False):
    """ Decodes an input to a list of the corresponding raw bytes and to a
    list of the corresponding production rules (AST node ids).
    """
    global char2int, int2char
    input_raw = str(line[0])

    # Remove hex stuff
    input_raw = input_raw.replace(":", "").split("0x")[1:]
    input_raw = map(lambda x: int(x, 16), input_raw)
    for _ in range(input_size - len(input_raw)):
        input_raw.append(0)

    input_ast = list(line[2])
    input_ast = [char2int.get(char, char2int['<UNK>'])
                 for char in input_ast]
    if padding:
        for _ in range(input_size - len(input_ast)):
            input_ast.append(0)

    return input_raw[:input_size], input_ast[:input_size]


def decode_output(line):
    """ Unravels the bitmap of control flow paths exercised by the current
    input.
    """
    output = line[1]
    return [float(o) for o in output]


def is_subbitmap(bitmap, dataset):
    """ Decides if an execution path is a subset of another. (This is helpful
    to merge equvalent test cases.)
    """
    bitmaps = map(lambda x: sorted(np.where(np.array(list(x[1])) == '1')[0].\
                                   tolist()),
                  dataset)
    bitmaps = map(lambda x: ",".join(map(str,  x)), bitmaps)

    bitmap = sorted(np.where(np.array(list(bitmap)) == '1')[0].tolist())
    current_bitmap = ",".join(map(str,  bitmap))
    for bitmap in bitmaps:
        if current_bitmap in bitmaps:
            return True
    return False


def input_iterator(hps, args, mode, verbose=True, calibrate=True):
    """ Main input iterator used by tensorflow to fetch inputs during training
    and tetsting and from Pythia to fetch inputs during fuzzing.

    @param hps:  Model hyperparameters
    @type  hps:  Tensorflow HParam
    @param args: Command line arguments
    @type  args: Class ArgumentParser
    @param mode: Argument controlling training, testing, or fuzzing
    @type  mode: Str
    @param verbose: Debug flag
    @type  verbose: Bool
    @param calibrate: Flag controlling whether to apply calibration or not
    @type  calibrate: Bool

    @return: Input/output tensor
    @rtype:  Tensor tuple
    """
    global char2int

    print("Mode: {}".format(mode), file=args.f)
    print("Dataset path: {}".format(hps.dataset), file=args.f)

    input_size = hps.input_size
    output_size = hps.output_size
    batch_size = hps.batch_size

    if not input_iterator.dataset:
        # Bring file in memory to be faster
        dataset = []
        with open(hps.dataset, "r") as f:
            # Skip header
            f.next()
            for line in f:
                line = line.strip().split(",")
                try:
                    dataset.append((line[0], line[1], map(int, line[2:])))
                except Exception, error:
                    print("random_generator:: Exception1:", error)
                    continue

        input_iterator.dataset = dataset[:]
        make_indices(input_iterator)

        average_len = sum([len(x[2]) for x in dataset])/len(dataset)
        print("Average sequence length before calibration:", average_len,
              file=args.f)

        dataset = do_calibration(dataset, args, mode)

        average_len = sum([len(x[2]) for x in dataset])/len(dataset)
        print("Average sequence length after calibration:", average_len,
              file=args.f)
        input_iterator.dataset = dataset[:]

    dataset_lines = input_iterator.dataset
    print("Total sequences found:", len(input_iterator.dataset), file=args.f)
    print("Training sequences:", len(input_iterator.dataset), file=args.f)
    print("Hash of recovered seeds: {}".\
          format(hash(str(map(lambda x: x[1], input_iterator.dataset)))),
          file=args.f)

    def random_generator():
        """ Used for training. """
        epochs = 0
        while True:
            random.shuffle(dataset_lines)
            for i in range(len(dataset_lines)):
                try:
                    input_raw, input_ast = decode_input(dataset_lines[i],
                                                        input_size)
                    output = decode_output(dataset_lines[i])
                except Exception, error:
                    print("random_generator:: Exception2:", error)
                    continue
                yield input_raw, input_ast, output,

            if verbose:
                print("Iterator:: Finished epoch: {} (random order)".\
                      format(epochs), file=args.f)
            epochs += 1

    def sequencial_generator():
        """ Used for testing. """
        epochs = 0
        while True:
            for i in range(len(dataset_lines)):
                try:
                    input_raw, input_ast = decode_input(dataset_lines[i],
                                                        input_size)
                    output = decode_output(dataset_lines[i])
                except Exception, error:
                    print("sequential_generator:: Exception1:", error)
                    continue

                yield input_raw, input_ast, output,

            if verbose:
                print("Iterator:: Finished epoch: {} (sequential order)".\
                      format(epochs), file=args.f)
            epochs += 1

    if mode == 'train':
        generator = random_generator
    elif mode in ['test', 'fuzz']:
        generator = sequencial_generator
    else:
        raise ValueError("\"mode\": {} not supported".format(mode))

    dataset = tf.data.Dataset.from_generator(
        generator,
        output_types=(
            tf.int32,
            tf.int32,
            tf.int32
        ),
        output_shapes=(
            tf.TensorShape([input_size]),
            tf.TensorShape([None]),
            tf.TensorShape([output_size])
        ),
    )
    dataset = dataset.padded_batch(
        batch_size,
        padded_shapes=(
            tf.TensorShape([None]),
            tf.TensorShape([None]),
            tf.TensorShape([None])),
        padding_values=(
            tf.constant(char2int['<PAD>']),
            tf.constant(char2int['<PAD>']),
            tf.constant(char2int['<PAD>']),
        )
    )
    return dataset.make_initializable_iterator()
input_iterator.dataset = []


def reconstruct_sequence_from_ast(sequence, hps, mutation_at_index=None):
    """ Core function that traverses and AST of production rules, applies
    mutations (if applicable), and reconstructs the mutated test case.

    @param sequence:  List of production rules (in-order AST traversal)
    @type  sequence:  List
    @param hps:  Model hyperparameters
    @type  hps:  Tensorflow HParam
    @param mutation_at_index:  Index of production rule (AST leaf node) at which
    to add random, raw-byte mutations (if applicable)
    @type mutation_at_index: Int

    @return: Input/output tensor
    @rtype:  Tensor tuple
    """
    global char2int, int2char

    def src2func(parser_src):
        """ Helper to convert a function (RESTler response parser) into actual,
        executable code."""

        parser_src = parser_src[9:]

        # Get name
        parser_name = str(parser_src[:parser_src.index(":")])
        parser_name = parser_name.split(' ')[1].split('(')[0]

        # Get src
        parser_src = parser_src.replace("ResponseParsingException", "Exception")

        # Find where to put the return statement.
        start_ind = parser_src.index("dependencies.set_variable")
        end_ind = start_ind + parser_src[start_ind:].index(")")
        refined_parser_src = str(parser_src[:start_ind])
        refined_parser_src += "return {}\n\telse:\n\t\treturn ''".format(
            parser_src[start_ind:end_ind].split(" ")[1])

        # Turn string to callable function object
        func = compile(refined_parser_src, "/tmp/" + parser_name, "exec")
        return FunctionType(func.co_consts[0], globals())

    # Load header of production rules only once
    if not reconstruct_sequence_from_ast.production_rules:
        with open(hps.dataset, "r") as f:
            header = f.next()
        header = header.split('production_rules:')[1]
        try:
            production_rules = json.loads(header)
        except Exception, error1:
            try:
                production_rules = dict(eval(header))
            except Exception, error2:
                print("reconstruct_sequence_from_ast: error1", error1)
                print("reconstruct_sequence_from_ast: error2", error2)
        reconstruct_sequence_from_ast.production_rules = production_rules
        reconstruct_sequence_from_ast.id2rule =\
            {int(k):v for k,v in production_rules.items()}
        reconstruct_sequence_from_ast.char2int = char2int
        reconstruct_sequence_from_ast.int2char = int2char

    payloads = []
    consumers = []
    producers = []
    new_rule_ascii = []
    current_payload = ""
    current_producers = []
    current_consumers = []
    id2rule = reconstruct_sequence_from_ast.id2rule

    # Process the in-order traversal, reconstruct, and apply mutation
    for seq_ind, id in enumerate(sequence):
        if id == 0:
            break
        elif 'LEAF' not in id2rule[id]:
            if 'request --> e' in id2rule[id]:
                payloads.append(str(current_payload))
                producers.append(current_producers)
                consumers.append(current_consumers)
                if not current_payload:
                    raise SequenceReconstructionException(
                        "Can't reconstruct valid sequece")
                current_payload = ""
                current_producers = []
                current_consumers = []
        elif "producer_" in id2rule[id]:
            terminal = id2rule[id].split("-->")[1][2:-1]
            current_producers.append(src2func(terminal))
        elif "consumer" in id2rule[id]:
            terminal = id2rule[id].split("-->")[1][2:-1]
            current_consumers.append(terminal)
            current_payload_ascii = map(ord, list(current_payload))
            terminal_ascii = map(ord, list(terminal))
            delim_start_ascii = map(ord, list("READER_START_"))
            delim_end_ascii = map(ord, list("_READER_END"))
            current_payload_ascii = current_payload_ascii + delim_start_ascii\
                + terminal_ascii + delim_end_ascii
            current_payload = "".join(map(chr, current_payload_ascii))
        else:
            terminal = id2rule[id].split("-->")[1][2:-1]
            if mutation_at_index is not None and seq_ind == mutation_at_index:
                old_rule_operands = id2rule[id].split("-->")
                if len(terminal):
                    terminal = str(terminal)
                    terminal = map(ord, terminal)
                    position = random.randint(0, len(terminal)-1)
                    terminal[position] = random.randint(0, 255)
                    terminal = "".join(map(chr, terminal))
                else:
                    terminal = [random.randint(0, 255)]
                    terminal = "".join(map(chr, terminal))

                new_rule_operand_a = map(ord, old_rule_operands[0])
                new_rule_operand_b = map(ord, terminal)
                operator = map(ord, "-->")

                # Use this hack to recover two characters from the begining of
                # the old terminal, and one character from the end.
                old_rule_operand_b = map(ord, old_rule_operands[1])
                new_rule_ascii = new_rule_operand_a + operator\
                    + old_rule_operand_b[:2] + new_rule_operand_b\
                    + [old_rule_operand_b[-1]]

            current_payload_ascii = map(ord, list(current_payload))
            terminal_ascii = map(ord, list(terminal))
            current_payload_ascii = current_payload_ascii + terminal_ascii
            current_payload = "".join(map(chr, current_payload_ascii))

    if not payloads:
        raise SequenceReconstructionException("Can't reconstruct valid sequece")

    return zip(payloads, consumers, producers),\
        (mutation_at_index, new_rule_ascii)
reconstruct_sequence_from_ast.production_rules = {}


def revert(sequence):
    """ Helper to translate between dictionaries. """
    global char2int, int2char
    return [int2char[c] for c in sequence if c != char2int["<PAD>"]]


def remove_padding_and_add_eos(sequence):
    """ Helper to translate between dictionaries. """
    global char2int, int2char
    s = []
    for c in sequence:
        if c == char2int["<PAD>"]:
            break
        s.append(int2char[c])
    s.append(char2int["<EOS>"])
    return s


def reconstruct_sequence_raw(sequence):
    """ Helper to reconstruct hexadecimals to readable bytes. """
    return "".join([chr(c) for c in sequence])
